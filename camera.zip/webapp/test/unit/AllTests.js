sap.ui.define([
	"camera/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
