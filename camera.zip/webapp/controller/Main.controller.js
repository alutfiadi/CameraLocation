/* global Webcam:true */
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    'sap/ui/core/HTML'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,
        HTML) {
        "use strict";

        return Controller.extend("camera.controller.Main", {
            onInit: function () {


            },
            onAfterRendering: function () {
                var webID = this.createId("webcam"); // this == controller instance
                var webcamElement = document.getElementById(webID);
                var canvasID = this.createId("canvas");
                var canvasElement = document.getElementById(canvasID);
                var snapSoundID = this.createId("snapSound");
                var snapSoundElement = document.getElementById(snapSoundID);

                console.log("Webcam ", webcamElement);
                console.log("canvasElement ", canvasElement);
                console.log("snapSoundElement ", snapSoundElement);

                this.webcam = new Webcam(webcamElement, 'user', canvasElement, null);
                this.webcam.start()
                    .then(result => {
                        console.log("webcam started");
                    })
                    .catch(err => {
                        console.log(err);
                    });

            },
            
            takePhoto: function (){
                var picture = this.webcam.snap();
                console.log(picture);
                this.aftertakePhoto();
            },

            aftertakePhoto: function(){
                this.webcam.stop();
            }
        });
    });
